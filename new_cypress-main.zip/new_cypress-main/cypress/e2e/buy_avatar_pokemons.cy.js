import * as New_Avatar from "../locators/New_Avatar.json";
import * as data from "../helpers/data_pokemons.json"

describe('Покупка аватара на сайте Покемонов', function () {

    it('e2e Покупка аватара на сайте Покемонов', function () {
         cy.visit('https://pokemonbattle.ru/');
         cy.get('.style_1_popup_white_title').should('be.visible');
         cy.get('.auth_content_text').should('be.visible');
         cy.get('.auth_content_social_icon').should('be.visible');
         cy.get('.style_1_popup_white_link_left').should('be.visible');
         cy.get('.style_fix_1').should('be.visible');
         cy.get('#k_email').type(data.login); 
         cy.get('#k_password').type(data.password); 
         cy.get('.MuiButton-root').click();
         cy.wait(3000)
         cy.get('.header_card_trainer').click();
         cy.wait(2500)
         cy.get('.k_mobile > :nth-child(5)').click();
         cy.wait(2000)
         //cy.get(New_Avatar.new_avatar4).click(); - написала это до того как посмотрела подсказку
         cy.get('.available > button').first().click();
         cy.get('.payment_form_card_form > :nth-child(2) > .style_1_base_input').type(data.number_card); 
         cy.get(':nth-child(1) > .style_1_base_input').type(data.data_card); 
         cy.get('.payment_form_card_form_inputs > :nth-child(2) > .style_1_base_input').type(data.cvv); 
         cy.get('.payment_form_card_form_input_last > .style_1_base_input').type(data.name); 
         cy.wait(1500)
         cy.get('.style_1_base_button_payment_body > .style_1_base_button_payment').click();
         cy.get('.timer_reset').should('be.visible');
         cy.get('.style_1_base_link_blue_exit').should('be.visible');
         cy.get('.style_1_base_input').type(data.approved_sms); 
         cy.get('.style_1_base_button_payment_body > .style_1_base_button_payment').click();
         cy.get('.payment_status_top_title').contains('Покупка прошла успешно'); 
         cy.get('.style_1_base_link_blue').click();
    })     

})

// не знаю почему, но иногда были проблемы с повторными прогонами. могу предположить что клики делались раньше, чем сайт думал.
// перед тем как отрпавить домашку, я ее прогнала 5 раз на всякий случай :)
