import * as MainPage from "../locators/MainPage.json";
import * as ChangePass from "../locators/ChangePassword.json";
import * as ResultPage from "../locators/ResultPage.json";
import * as data from "../helpers/default_data.json"

describe('Проверка авторизации на сайте', function () {

   beforeEach('Начало теста', function () {
         cy.visit('/');
         cy.get(MainPage.forgot_pass).should('have.css', 'color', 'rgb(0, 85, 152)');
           });

   afterEach('Конец теста', function () {
         cy.get(ResultPage.exit).should('be.visible');
        });


    it('Проверка валидного логина и пароля', function () {
         cy.get (MainPage.email).type(data.login); 
         cy.get (MainPage.password).type(data.password); 
         cy.get (MainPage.log_in).click();
         cy.get (ResultPage.header).should('be.visible');
         cy.get (ResultPage.header).contains('Авторизация прошла успешно')
    })    

        it('Проверка валидного логина и невалидного пароля', function () {
         cy.get (MainPage.email).type(data.login); 
         cy.get (MainPage.password).type('iLoveqastudio1111'); 
         cy.get (MainPage.log_in).click();
         cy.get (ResultPage.header).should('be.visible');
         cy.get (ResultPage.header).contains('Такого логина или пароля нет')
    })    

        it('Проверка невалидного логина и валидного пароля', function () {
         cy.get (MainPage.email).type('germa@dolnikov.ru'); 
         cy.get (MainPage.password).type(data.password); 
         cy.get (MainPage.log_in).click();
         cy.get (ResultPage.header).should('be.visible');
         cy.get (ResultPage.header).contains('Такого логина или пароля нет')
    })   

        it('Проверка логина без @ и валидного пароля', function () {
         cy.get (MainPage.email).type('germandolnikov.ru'); 
         cy.get (MainPage.password).type(data.password); 
         cy.get (MainPage.log_in).click();
         cy.get (ResultPage.header).should('be.visible');
         cy.get (ResultPage.header).contains('Нужно исправить проблему валидации')
    })   

        it('Проверка на приведение к строчным буквам в логине', function () {
         cy.get (MainPage.email).type('German@dolnikov.ru'); 
         cy.get (MainPage.password).type(data.password); 
         cy.get (MainPage.log_in).click();
         cy.get (ResultPage.header).should('be.visible');
         cy.get (ResultPage.header).contains('Такого логина или пароля нет')
    })   

        it('Проверка восстановления  пароля', function () {
         cy.get (MainPage.forgot_pass).click(); 
         cy.get (ChangePass.email).type(data.login); 
         cy.get (ChangePass.send_code).click();
         cy.get (ResultPage.header).should('be.visible');
         cy.get (ResultPage.header).contains('Успешно отправили пароль на e-mail')
    })   
})
